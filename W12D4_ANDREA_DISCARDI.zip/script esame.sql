-- create schema ToysGroup;

CREATE TABLE Prodotto (
    ID_Prodotto INT PRIMARY KEY,
    Nome_Prodotto VARCHAR(50) NOT NULL,
    Categoria VARCHAR(50) NOT NULL
);


CREATE TABLE Regione (
    ID_Regione INT PRIMARY KEY,
    Nome_Regione VARCHAR(50),
    Provincia VARCHAR(2)
);

CREATE TABLE Vendita (
    ID_Prodotto int,
    ID_Vendita INT PRIMARY KEY,
    ID_Regione Int,
    Data_Vendita date,
    Quantità_Venduta int,
    Costi_Produzione decimal (10,2),
    Prezzo_Vendita decimal (10,2),
   FOREIGN KEY (ID_Prodotto) REFERENCES prodotto(ID_Prodotto),
   FOREIGN KEY (ID_Regione) REFERENCES regione(ID_Regione)
	);



INSERT INTO prodotto (ID_Prodotto, Nome_Prodotto, Categoria)  VALUES
 (1, 'Drone', 'telecomandato'),
 (2, 'puzzle venezia', 'gioco da tavolo'),
 (3, 'UNO', 'gioco da tavolo'),
 (4, 'orso', 'peluche'),
 (5, 'unicorno', 'peluche'),
 (6, 'macchina', 'telecomandato'),
 (7, 'Supereroe', 'verosimile'),
 (8, 'ragno', 'verosimile'),
 (9, 'shangai', 'gioco da tavolo'),
 (10, 'Monopoli', 'gioco da tavolo');
 
 INSERT INTO Regione (ID_Regione, Nome_Regione, Provincia)  VALUES
 ('26', 'Veneto', 'VE'),
('27', 'Lombardia', 'MI'),
('28', 'Piemonte',	'TO'),
('29', 'Sardegna',	'CA'),
('30', 'Campania',	'NA')
;

INSERT INTO Vendita (ID_Prodotto, ID_Vendita, ID_Regione, Data_Vendita, Quantità_Venduta, Costi_Produzione, Prezzo_Vendita) VALUES
(1, 11, 30, '2023-01-26', 426, 60.00, 150.00),
(2, 12, 27, '2023-02-07', 29, 2.50, 7.99),
(3, 13, 28, '2023-02-19', 43, 3.11, 12.00),
(4, 14, 30, '2023-03-03', 2, 8.40, 29.00),
(5, 15, 26, '2023-03-15', 86, 6.20, 19.00),
(6, 16, 29, '2023-03-27', 93, 36.38, 80.00),
(7, 17, 29, '2023-04-08', 0, 7.40, 24.00),
(8, 18, 26, '2023-04-20', 53, 7.20, 18.00),
(9, 19, 26, '2023-05-02', 86, 2.80, 9.00),
(10, 20, 28, '2023-05-14', 21, 12.50, 35.00);


-- 1. Verificare che i campi definiti come PK siano univoci. 
-- non mi ricordo il modo corretto allora ho improvvisato: il risultato è 0 righe perchè ogni singolo valore non c'è più di una volta 

SELECT distinct ID_Vendita, COUNT(*) 
FROM vendita
GROUP BY ID_Vendita

HAVING COUNT(*) >1;

SELECT distinct ID_Regione, COUNT(*) 
FROM Regione
GROUP BY ID_Regione

HAVING COUNT(*) >1;

SELECT distinct ID_Prodotto, COUNT(*) 
FROM Prodotto
GROUP BY ID_Prodotto

HAVING COUNT(*) >1;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
SELECT 
    prodotto.Nome_Prodotto,
    vendita.Prezzo_Vendita * vendita.Quantità_Venduta AS FatturatoTot,
    YEAR(vendita.Data_Vendita) AS Anno
FROM
    prodotto
        JOIN
    vendita ON prodotto.ID_Prodotto = vendita.ID_Prodotto
    
;
 
-- 3.Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT 
    regione.Nome_Regione AS Regione,
    YEAR(vendita.Data_Vendita) AS Anno,
    SUM(vendita.Prezzo_Vendita * vendita.Quantità_Venduta) AS FatturatoTotale
FROM
    vendita
        JOIN
    regione ON vendita.ID_Regione = regione.ID_Regione
GROUP BY regione.Nome_Regione,Anno
ORDER BY Anno,FatturatoTotale DESC;

-- 4.Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT
    prodotto.Categoria, MAX(Quantità_Venduta) AS QuantitàVenduta
FROM
    prodotto
        JOIN
    vendita ON prodotto.ID_Prodotto = vendita.ID_Prodotto
GROUP BY prodotto.Categoria
LIMIT 1
;
-- 5.Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

select
prodotto.Nome_Prodotto,
vendita.Quantità_Venduta
FROM
    prodotto
        JOIN
    vendita ON prodotto.ID_Prodotto = vendita.ID_Prodotto
   WHERE vendita.Quantità_Venduta = 0
   ;
  
 SELECT 
    prodotto.Nome_Prodotto, vendite_zero.Quantità_Venduta
FROM
    prodotto
        JOIN
    (SELECT 
        ID_Prodotto, Quantità_Venduta
    FROM
        vendita
    WHERE
        Quantità_Venduta = 0) AS vendite_zero ON prodotto.ID_Prodotto = vendite_zero.ID_Prodotto
        ;

-- 6.Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
-- Nei dati ho messo una singola data di vendita ogni prodotto, la prima riga dell'output di questa query è l'ultima vendita di questa fabbrica

/*select 
p.Nome_Prodotto,
v.Data_Vendita
FROM
    prodotto p
        JOIN
    vendita v ON p.ID_Prodotto = v.ID_Prodotto
   ;*/

SELECT 
    p.ID_Prodotto,
    p.Nome_Prodotto,
    max(v.Data_Vendita) AS ultima_data_vendita
FROM
    prodotto p
        JOIN
    vendita v ON p.ID_Prodotto = v.ID_Prodotto
GROUP BY p.ID_Prodotto , p.Nome_Prodotto
ORDER BY ultima_data_vendita DESC
    
;



